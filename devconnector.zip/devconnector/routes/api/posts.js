const express = require("express");
const router = express.Router();

//@endpoint /api/posts/test
// @method : GET
// @Access : public
// @DEsc : test the posts route

router.get("/test", (req, res) => {
  res.json({ msg: "posts works" });
});

module.exports = router;
