const express = require("express");

const bcrypt = require("bcryptjs");
const router = express.Router();

// Load input validation

const validateRegisterInput = require("../../validation/register");

const User = require("../../models/User");
//@endpoint /api/users/test
// @method : GET
// @Access : public
// @DEsc : test the user route

router.get("/test", (req, res) => {
  res.json({ msg: "user works" });
});

//@endpoint /api/users/register
// @method : post
// @Access : public
// @DEsc : to register the user

router.post("/register", (req, res) => {
  console.log(req.body);

  const { errors, isValid } = validateRegisterInput(req.body);
  if (!isValid) {
    return res.status(400).json(errors);
  }

  User.findOne({ email: req.body.email }).then((user) => {
    if (user) {
      // if user exists ==> retrun error message : Email already Exists
      errors.email = "Email already Exists";
      return res.status(400).json(errors);
    } else {
      // if not what to do create a new record
      const newUser = new User({
        name: req.body.name,
        email: req.body.email,
        password: req.body.password,
      });

      bcrypt.genSalt(10, (err, salt) => {
        bcrypt.hash(newUser.password, salt, (err, hash) => {
          if (err) throw err;
          newUser.password = hash;
          newUser
            .save()
            .then((user) => res.json(user))
            .catch((err) => console.log(JSON.stringify(err)));
        });
      });
    }
  });
  //res.send(req.body);
});

module.exports = router;
